import React from "react";
import Timeline from "./Timeline/Timeline";

function App() {
  const eventArr = [
    {
      name: "event1",
      sdate: "2020/03/25",
      edate: "2020/03/30",
    },
    {
      name: "event2",
      sdate: "2020/03/25",
      edate: "2020/04/03",
    },
    {
      name: "event3",
      sdate: "2020/04/02",
      edate: "2020/04/08",
    },
  ];
  return (
    <div className="App">
      <h1>Hello CodeSandbox</h1>
      <h2>Start editing to see some magic happen!</h2>
      <Timeline startDate="2020/03/25" endDate="2020/04/20" events={eventArr} />
    </div>
  );
}

export default App;
