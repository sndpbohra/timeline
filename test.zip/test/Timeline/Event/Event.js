import React from "react";
import { getEventDates } from "../../utility";
import "../Timeline.css";

const event = ({ event, dateArr, className }) => {
  const eventDates = getEventDates(dateArr, event.sdate, event.edate);
  const eventData = eventDates.map((eventDate, index) => {
    if (eventDate) {
      return <div key={eventDate.getTime()+'_'+event.name}>{event.name}</div>;
    } else {
      return <div key={index+'_'+event.name}>&nbsp;</div>;
    }
  });

  return <div className={className}>{eventData}</div>;
};

export default event;
