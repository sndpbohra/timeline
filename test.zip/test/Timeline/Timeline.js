import React from "react";
import "./Timeline.css";
import { getDates, months } from "../utility";
import Event from './Event/Event';

const timeline = ({ startDate, endDate, events }) => {
  const dateArr = getDates(startDate, endDate, events);

  let timelineData = null;

  if (dateArr.length > 0) {
    timelineData = dateArr.map((d) => (
      <div key={d.getTime()}>
        {d.getDate()} {months[d.getMonth()]}
      </div>
    ));
  }

  let eventsData = null;

  if(events.length > 0) {
    eventsData = events.map(event => (
      <Event key={event.name} className="Timeline" event={event} dateArr={dateArr} />
    ))
  }

  return (
    <div>
      <div className="Timeline">{timelineData}</div>
      {eventsData}
    </div>
  );
};

export default timeline;
